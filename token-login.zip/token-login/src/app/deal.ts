export class Deal {
    id: number;
    name: string; 
    description: string;
    origionalPrice: number;
    salePrice: number;
    
}