import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import {routing, routedComponents } from './app.routing';

import { DealService } from './deal.service';

@NgModule({

  imports: [
    BrowserModule,
    FormsModule,
    routing,
    HttpModule,
  ],

  declarations: [
    AppComponent,
    routedComponents
  ],

  providers: [
    DealService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
