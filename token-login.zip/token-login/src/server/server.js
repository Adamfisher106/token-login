//this file will be the angular2 application. it will be using Auth0 to set up the authentication system this is the code to go with it

'use strict';

const express = require('express');
const app = express();
// import the dependencies

const jwt = require('express-jwt');
const jwks = require('jwks-rsa');
const cors = require ('cors');
const bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());


const authCheck = jwk({
    secret: jwks.expressJwkSecret({
        cache: true,
        rateLimit: true,
        jwksRequestsPerMinute: 5,
        jwksUri: "https://{YOUR-AUTH0-DOMAIN}.auth0.com/.well-known/jwks.json"
    }),

    // this will identify the api that you have created
    audicence: '{Your-API-AUDIENCE-ATTRIBUTE}',
    issuer: "http://{YOUR-AUTH0-DOMAIN}.auth0.com/",
    algorithms: ['RS256']
});

app.get('/api/deals/public', (req, res)=>{
    let deals=[

    ];

    res.json(deals);

})

app.get('/api/deals/private', authCheck, (req,res)=>{
    let deals = [

    ];
    res.json(deals);
})
app.listen(3001);
console.log('Listening on localhost:3001');